package main;

import model.WordRepository;
import model.Word;
import model.Game;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        
        WordRepository repository = WordRepository.createJsonRepository();

        System.out.println("FIND MY WORD\n");

        int nbJoueurs = 0;
        while (nbJoueurs != 1 && nbJoueurs != 2) {
            System.out.print("Choisissez le nombre de joueurs (1 ou 2) : ");
            String choix = scanner.nextLine().trim();
            if (choix.equals("1")) {
                nbJoueurs = 1;
            } else if (choix.equals("2")) {
                nbJoueurs = 2;
            }
        }

        int nbSeries = 0;
        while (nbSeries != 1 && nbSeries != 5 && nbSeries != 10 && nbSeries != 20) {
            System.out.print("Choisissez le nombre de séries (1, 5, 10, 20) : ");
            String choix = scanner.nextLine().trim();
            if (choix.equals("1")) {
                nbSeries = 1;
            } else if (choix.equals("5")) {
                nbSeries = 5;
            } else if (choix.equals("10")) {
                nbSeries = 10;
            } else if (choix.equals("20")) {
                nbSeries = 20;
            }
        }

        List<String> joueurs = new ArrayList<>();
        int[] scoresTotaux = new int[nbJoueurs];

        if (nbJoueurs == 1) {
            System.out.print("Entrez votre nom : ");
            joueurs.add(scanner.nextLine().trim());
            System.out.println("\n" + joueurs.get(0) + ", vous aurez du coup " + nbSeries + " séries. Chaque série contient 6 essais, vous devrez trouver le bon mot pour gagner, bon courage !!!!\n");
        } else {
            System.out.print("Entrez le nom du joueur 1 : ");
            joueurs.add(scanner.nextLine().trim());
            System.out.print("Entrez le nom du joueur 2 : ");
            joueurs.add(scanner.nextLine().trim());
            System.out.println("\n" + joueurs.get(0) + " et " + joueurs.get(1) + ", vous aurez du coup " + nbSeries + " séries. Chaque série contient 6 essais, le premier qui trouve le bon mot gagne, bon courage !!!!\n");
        }

        for (int i = 1; i <= nbSeries; i++) {
            System.out.println("--- SÉRIE " + i + " ---");
            
            Game game = new Game(repository, joueurs);
            int[] scoresManche = game.start();
            
            for (int j = 0; j < nbJoueurs; j++) {
                scoresTotaux[j] = scoresTotaux[j] + scoresManche[j];
            }
            System.out.println();
        }

        System.out.println("=== SCORES FINAUX ===");
        for (int i = 0; i < nbJoueurs; i++) {
            System.out.println(joueurs.get(i) + " : " + scoresTotaux[i] + " points");
        }
        
        if (nbJoueurs == 2) {
            if (scoresTotaux[0] > scoresTotaux[1]) {
                System.out.println("\nLe gagnant est " + joueurs.get(0) + " !");
            } else if (scoresTotaux[1] > scoresTotaux[0]) {
                System.out.println("\nLe gagnant est " + joueurs.get(1) + " !");
            } else {
                System.out.println("\nMatch nul ! " + joueurs.get(0) + " et " + joueurs.get(1) + " sont à égalité.");
            }
        } else {
            System.out.println("\nBravo " + joueurs.get(0) + " pour ce score !");
        }
        
        System.out.println("\nFin du jeu ! Merci d'avoir joué.");
    }
}