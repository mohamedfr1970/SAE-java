#!/bin/bash
javac -d bin model/*.java main/*.java
java -cp bin main.Main