package model;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class Game {
    private Word secretWord;
    private int maxAttempts = 6;
    private List<String> playerNames;
    private List<List<Word>> playerAttempts;
    private int[] scores;

    public Game(WordRepository repository, List<String> playerNames) throws Exception {
        this.secretWord = repository.getWord();
        this.playerNames = playerNames;
        this.playerAttempts = new ArrayList<>();
        for (int i = 0; i < playerNames.size(); i++) {
            this.playerAttempts.add(new ArrayList<>());
        }
        this.scores = new int[playerNames.size()];
    }

    public int[] start() {
        Scanner scanner = new Scanner(System.in);
        int numPlayers = this.playerNames.size();
        int turn = 0;
        boolean won = false;

        while (turn < this.maxAttempts * numPlayers) {
            int pIndex = turn % numPlayers;
            String currentPlayer = this.playerNames.get(pIndex);
            List<Word> currentAttempts = this.playerAttempts.get(pIndex);

            System.out.println("\nGrille de " + currentPlayer + " :");
            this.printGrid(currentAttempts);
            System.out.println();

            if (numPlayers == 1) {
                System.out.print("Tentative " + (currentAttempts.size() + 1) + " : ");
            } else {
                System.out.print("[" + currentPlayer + "] Tentative " + (currentAttempts.size() + 1) + " : ");
            }

            String input = scanner.nextLine();
            Word guess = new Word(input);

            if (!guess.isLengthValid()) {
                System.out.println("Erreur : le mot doit contenir exactement 5 lettres.");
                continue;
            }
            if (!guess.isAlphaValid()) {
                System.out.println("Erreur : le mot doit contenir uniquement des lettres.");
                continue;
            }
            if (!guess.hasNoDuplicates()) {
                System.out.println("Erreur : le mot ne doit pas contenir de lettre répétée.");
                continue;
            }

            currentAttempts.add(guess);
            this.printAnalysis(guess);

            if (guess.getValue().equals(this.secretWord.getValue())) {
                System.out.println("\nBravo " + currentPlayer + " !");
                int pointsEarned = 7 - currentAttempts.size();
                this.scores[pIndex] = pointsEarned;
                System.out.println("Vous avez trouvé le mot en " + currentAttempts.size() + " essais.");
                System.out.println("Vous avez acquis " + pointsEarned + " points.\n");
                won = true;
                break;
            }

            turn++;
        }
        
        if (!won) {
            System.out.println("\nVous avez utilisé tous vos essais.");
            System.out.println("Partie perdue.");
            System.out.println("Le mot secret était : " + this.secretWord.getValue() + "\n");
        }

        return this.scores;
    }

    private void printGrid(List<Word> attempts) {
        for (int i = 0; i < this.maxAttempts; i++) {
            if (i < attempts.size()) {
                this.printAnalysis(attempts.get(i));
            } else {
                System.out.println("[ ][ ][ ][ ][ ]");
            }
        }
    }

    private void printAnalysis(Word guess) {
        String wordStr = guess.getValue();
        String secretStr = this.secretWord.getValue();
        
        for (int i = 0; i < 5; i++) {
            System.out.print("[" + wordStr.charAt(i) + "]");
        }
        System.out.print(" -> ");
        
        for (int i = 0; i < 5; i++) {
            char c = wordStr.charAt(i);
            if (c == secretStr.charAt(i)) {
                System.out.print("OK ");
            } else if (secretStr.indexOf(c) != -1) {
                System.out.print("PRESENT ");
            } else {
                System.out.print("ABSENT ");
            }
        }
        System.out.println();
    }
}