package model;

public class Word {
    private String value;

    public Word(String value) {
        this.value = value.toUpperCase();
    }

    public String getValue() {
        return this.value;
    }

    public boolean isLengthValid() {
        if (this.value.length() == 5) {
            return true;
        }
        return false;
    }

    public boolean isAlphaValid() {
        for (int i = 0; i < this.value.length(); i++) {
            char c = this.value.charAt(i);
            if (c < 'A' || c > 'Z') {
                return false;
            }
        }
        return true;
    }

    public boolean hasNoDuplicates() {
        for (int i = 0; i < this.value.length(); i++) {
            for (int j = i + 1; j < this.value.length(); j++) {
                if (this.value.charAt(i) == this.value.charAt(j)) {
                    return false;
                }
            }
        }
        return true;
    }
}