package model;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public abstract class WordRepository {
    
    public abstract Word getWord() throws Exception;

    public static WordRepository createJsonRepository() throws Exception {
        return new JsonWordRepository();
    }
}

class JsonWordRepository extends WordRepository {
    private List<String> words;
    private Random random;

    public JsonWordRepository() throws Exception {
        this.words = new ArrayList<>();
        this.random = new Random();
        this.loadWords();
    }

    private void loadWords() throws Exception {
        File fichier = new File("wordset_bundle_etudiant/data/mots.json");
        Scanner lecteur = new Scanner(fichier);
        
        while (lecteur.hasNextLine()) {
            String ligne = lecteur.nextLine();
            String[] morceaux = ligne.split("\"");
            
            for (int i = 0; i < morceaux.length; i++) {
                String mot = morceaux[i].toUpperCase();
                if (mot.length() == 5) {
                    this.words.add(mot);
                }
            }
        }
        lecteur.close();
    }

    @Override
    public Word getWord() throws Exception {
        if (this.words.isEmpty()) {
            this.loadWords();
        }
        
        int index = this.random.nextInt(this.words.size());
        String chosenWord = this.words.get(index);
        
        this.words.remove(index);
        
        return new Word(chosenWord);
    }
}

class FixedWordRepository extends WordRepository {
    private String fixedValue;

    public FixedWordRepository(String fixedValue) {
        this.fixedValue = fixedValue;
    }

    @Override
    public Word getWord() {
        return new Word(this.fixedValue);
    }
}